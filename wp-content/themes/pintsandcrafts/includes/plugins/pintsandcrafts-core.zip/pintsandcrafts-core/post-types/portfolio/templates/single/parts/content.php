<div class="edgtf-ps-info-item edgtf-ps-content-item">
    <?php the_content(); ?>
</div>