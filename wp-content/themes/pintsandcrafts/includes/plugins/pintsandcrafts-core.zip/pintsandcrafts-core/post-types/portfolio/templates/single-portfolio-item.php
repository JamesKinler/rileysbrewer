<?php

get_header();

pintsandcrafts_edge_get_title();

do_action('pintsandcrafts_edge_action_before_main_content');

pintsandcrafts_core_get_single_portfolio();

get_footer();