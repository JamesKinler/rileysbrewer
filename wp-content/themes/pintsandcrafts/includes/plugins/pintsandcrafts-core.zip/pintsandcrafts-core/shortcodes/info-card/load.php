<?php

include_once PINTSANDCRAFTS_CORE_SHORTCODES_PATH . '/info-card/functions.php';
include_once PINTSANDCRAFTS_CORE_SHORTCODES_PATH . '/info-card/info-card.php';