<?php

include_once PINTSANDCRAFTS_CORE_SHORTCODES_PATH . '/full-screen-sections/functions.php';
include_once PINTSANDCRAFTS_CORE_SHORTCODES_PATH . '/full-screen-sections/full-screen-sections.php';
include_once PINTSANDCRAFTS_CORE_SHORTCODES_PATH . '/full-screen-sections/full-screen-sections-item.php';