<?php

include_once PINTSANDCRAFTS_CORE_SHORTCODES_PATH . '/team/functions.php';
include_once PINTSANDCRAFTS_CORE_SHORTCODES_PATH . '/team/team.php';