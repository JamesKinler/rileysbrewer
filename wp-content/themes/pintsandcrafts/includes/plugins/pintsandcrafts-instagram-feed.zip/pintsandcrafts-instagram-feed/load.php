<?php

include_once 'lib/pintsandcrafts-instagram-api.php';
include_once 'widgets/load.php';